"use client"
import React from "react"

export const  Third_Step = () =>{
return(
    <div className="space-y-4">
            <h2 className="text-xl font-bold">Add social media links</h2>
            {formData.socialLinks?.map((link, index) => (
              <div key={index} className="space-y-2">
                <Select
                  value={link.platform}
                  onValueChange={(value) => handleSocialLinkChange(index, "platform", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select platform" />
                  </SelectTrigger>
                  <SelectContent>
                    {socialPlatforms.map((platform) => (
                      <SelectItem key={platform.value} value={platform.value}>
                        {platform.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex items-center space-x-2">
                  <Input
                    type="url"
                    placeholder={socialPlatforms.find((p) =>p.value === link.platform)?.placeholder || "https://"}
                    value={link.url}
                    onChange={(e) => handleSocialLinkChange(index, "url", e.target.value)}
                    className={errors.socialLinks ? "border-red-500" : ""}
                  />
                  <Button variant="ghost" size="icon" onClick={() => handleRemoveSocialLink(index)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
            {errors.socialLinks && <p className="text-red-500 text-sm">{errors.socialLinks}</p>}
            <Button variant="outline" onClick={handleAddSocialLink} className="w-full">
              <Plus className="mr-2 h-4 w-4" /> Add another link
            </Button>
          </div>
)
} 

export default Third_Step